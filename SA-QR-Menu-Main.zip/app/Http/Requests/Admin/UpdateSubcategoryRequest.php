<?php

namespace App\Http\Requests\Admin;

class UpdateSubcategoryRequest extends StoreSubcategoryRequest {}
