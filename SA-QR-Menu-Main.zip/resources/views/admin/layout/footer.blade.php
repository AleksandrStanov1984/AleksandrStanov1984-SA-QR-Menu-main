<footer style="border-top:1px solid var(--line);padding:12px 14px;font-size:12px;color:var(--mut);">
    © {{ date('Y') }} {{ __('admin.brand') }}
</footer>
