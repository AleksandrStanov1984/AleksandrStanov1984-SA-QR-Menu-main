<aside class="admin-sidebar">
    @include('admin.restaurants.components.sidebar._user')
    @include('admin.restaurants.components.sidebar._nav')
</aside>
