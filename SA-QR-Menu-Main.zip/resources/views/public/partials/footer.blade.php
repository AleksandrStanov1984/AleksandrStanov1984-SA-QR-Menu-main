<footer class="std-footer">
    <div class="std-footer__icons">
        <a class="std-footer__icon" href="#" aria-label="Facebook">
            <img src="{{ $img('icons/facebook.svg') }}" alt="">
        </a>

        <a class="std-footer__icon" href="#" aria-label="Instagram">
            <img src="{{ $img('icons/instagram.svg') }}" alt="">
        </a>

        <a class="std-footer__icon" href="#" aria-label="WhatsApp">
            <img src="{{ $img('icons/whatsapp.svg') }}" alt="">
        </a>
    </div>

    <div class="std-footer__copy">© Создано с помощью SA Digital Menus</div>
</footer>
