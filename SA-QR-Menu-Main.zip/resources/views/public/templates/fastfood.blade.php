@extends('public.layouts.menu')
@section('content')
    ...html...
@endsection
