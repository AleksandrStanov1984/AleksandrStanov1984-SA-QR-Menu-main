<div class="card">
    <h2><?php echo e(__('admin.profile.h2')); ?></h2>

    <form method="POST" action="<?php echo e(route('admin.profile.update')); ?>">
        <?php echo csrf_field(); ?>

        <div class="grid">
            <div class="col6">
                <label><?php echo e(__('admin.fields.name')); ?></label>
                <input name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.email')); ?></label>
                <input value="<?php echo e($user->email); ?>" disabled>
            </div>
        </div>

        <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn ok" type="submit"><?php echo e(__('admin.common.save')); ?></button>
            <button class="btn secondary" type="button" onclick="openModal('emailModal')">
                <?php echo e(__('admin.profile.change_email_btn')); ?>

            </button>
            <button class="btn secondary" type="button" onclick="openModal('passModal')">
                <?php echo e(__('admin.profile.change_password_btn')); ?>

            </button>
        </div>
    </form>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/profile/components/user-card/index.blade.php ENDPATH**/ ?>