<div class="card" style="margin-top:16px;">
    <h2><?php echo e(__('admin.restaurants.brand.h2')); ?></h2>

    <?php if(!empty($restaurant->logo_path)): ?>
        <div style="margin:10px 0;">
            <img
                src="<?php echo e(asset('storage/' . $restaurant->logo_path)); ?>"
                alt="logo"
                style="max-height:64px; width:auto; display:block;">
        </div>
    <?php endif; ?>

    <form method="POST"
          action="<?php echo e(route('admin.restaurants.logo.update', $restaurant)); ?>"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <label><?php echo e(__('admin.restaurants.brand.logo_label')); ?></label>
        <input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp" required>

        <div style="margin-top:14px; display:flex; gap:10px; justify-content:flex-end;">
            <button class="btn ok" type="submit"><?php echo e(__('admin.common.save')); ?></button>
        </div>
    </form>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/logo.blade.php ENDPATH**/ ?>