<?php $__env->startSection('title', __('admin.restaurants.edit.title')); ?>
<?php $__env->startSection('subtitle', $restaurant->name); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('admin.dashboard.home')); ?></a>
    <span class="sep">›</span>
    <a href="<?php echo e(route('admin.restaurants.index')); ?>"><?php echo e(__('admin.restaurants.index.h1')); ?></a>
    <span class="sep">›</span>
    <span><?php echo e($restaurant->name); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.restaurants.components.edit._menu', [
    'restaurant' => $restaurant,
    'menuTree' => $menuTree,
    'locales' => $locales,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.restaurants.components.branding-backgrounds.index', ['restaurant' => $restaurant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.restaurants.components.edit._permissions', [
    'restaurant' => $restaurant,
    'restaurantUser' => $restaurantUser ?? null,
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.restaurants.components.edit._languages', ['restaurant' => $restaurant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/edit.blade.php ENDPATH**/ ?>