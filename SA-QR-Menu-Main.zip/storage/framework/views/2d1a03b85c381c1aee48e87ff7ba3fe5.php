<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo $__env->yieldContent('title', __('admin.common.admin')); ?> — <?php echo e(__('admin.brand')); ?></title>

<link rel="stylesheet" href="<?php echo e(asset('admin/css/admin.css')); ?>">
<script src="<?php echo e(asset('admin/js/form-helpers.js')); ?>"></script>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/layout/head.blade.php ENDPATH**/ ?>