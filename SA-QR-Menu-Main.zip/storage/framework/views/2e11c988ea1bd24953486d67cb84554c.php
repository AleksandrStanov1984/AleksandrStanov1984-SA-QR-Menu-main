<?php
  $items = $section->items ?? collect();
  $title = function($it) use ($defaultLocale){
    $tr = $it->translations->firstWhere('locale', $defaultLocale);
    return $tr->title ?? ('Item #'.$it->id);
  };
?>

<div class="mb-items"
     data-sortable-items
     data-reorder-url="<?php echo e(route('admin.restaurants.items.reorder', [$restaurant, $section])); ?>">
  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $m = $it->meta ?? [];
      $inactive = !$it->is_active;
      $isNew = !empty($m['is_new']);
      $isDay = !empty($m['dish_of_day']);
    ?>

    <div class="mb-item <?php echo e($inactive ? 'mb-inactive' : ''); ?>" data-item-id="<?php echo e($it->id); ?>">
      <div class="mb-item-head">
        <div class="mb-left">
          <span class="mb-handle">≡</span>

          <form method="POST" action="<?php echo e(route('admin.restaurants.items.toggle', [$restaurant, $it])); ?>">
            <?php echo csrf_field(); ?>
            <label style="margin:0; display:flex; align-items:center; gap:8px;">
              <input type="checkbox" <?php if($it->is_active): echo 'checked'; endif; ?> onchange="this.form.submit()">
              <span class="mb-item-title"><?php echo e($title($it)); ?></span>
            </label>
          </form>

          <?php if($isNew): ?><span class="pill green">NEW</span><?php endif; ?>
          <?php if($isDay): ?><span class="pill">★ Day</span><?php endif; ?>
          <?php if($inactive): ?><span class="pill red"><?php echo e(__('admin.common.disabled') ?? 'disabled'); ?></span><?php endif; ?>
        </div>

        <div class="mb-right">
          <div class="mb-mini">spicy: <?php echo e((int)($m['spicy'] ?? 0)); ?></div>

          <form method="POST" action="<?php echo e(route('admin.restaurants.items.destroy', [$restaurant, $it])); ?>"
                onsubmit="return confirm('Delete item?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn small danger" type="submit"><?php echo e(__('admin.actions.delete') ?? 'Delete'); ?></button>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/menu-builder/_items-list.blade.php ENDPATH**/ ?>