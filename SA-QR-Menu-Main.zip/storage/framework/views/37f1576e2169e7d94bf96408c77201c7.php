<?php
    $user = auth()->user();
    $isSuper = (bool)($user?->is_super_admin);
?>

<nav class="sb-nav">
    <ul>
        <li>
            <a href="#">
                🧾 <?php echo e(__('admin.sidebar.about')); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.profile')); ?>">
                👤 <?php echo e(__('admin.sidebar.profile')); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.menu.profile')); ?>">
                🍽 <?php echo e(__('admin.sidebar.my_menu')); ?>

            </a>
        </li>

        <li class="sb-has-sub">
            <a href="#" class="sb-parent" onclick="event.preventDefault(); this.parentElement.classList.toggle('open');">
                🔒 <?php echo e(__('admin.sidebar.security')); ?>

                <span class="sb-caret">▾</span>
            </a>

            <ul class="sb-sub">
                <li>
                    <a href="<?php echo e(route('admin.security.password')); ?>">
                        🔑 <?php echo e(__('admin.sidebar.password')); ?>

                    </a>

                </li>
            </ul>
       </li>




        <?php if($isSuper): ?>
            <li class="sb-sep"></li>

            <li>
                <a href="<?php echo e(route('admin.restaurants.index')); ?>">
                    🏪 <?php echo e(__('admin.sidebar.restaurants_select')); ?>

                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/sidebar/_nav.blade.php ENDPATH**/ ?>