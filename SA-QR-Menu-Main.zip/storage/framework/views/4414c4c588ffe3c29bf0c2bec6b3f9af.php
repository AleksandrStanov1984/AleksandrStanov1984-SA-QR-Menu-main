<div class="card" style="margin-top:16px;">
    <h2><?php echo e(__('admin.profile.permissions.h2')); ?></h2>

    <?php if(!empty($user) && !empty($user->is_super_admin)): ?>
        <div class="pill green"><?php echo e(__('admin.profile.permissions.super_admin')); ?></div>
    <?php endif; ?>

    <?php if(!empty($permissions) && count($permissions)): ?>
        <div style="margin-top:12px; display:flex; flex-wrap:wrap; gap:8px;">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="pill"><?php echo e($p); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="mut" style="font-size:13px; margin-top:8px;">
            <?php echo e(__('admin.profile.permissions.no_permissions')); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/profile/components/permissions-card/index.blade.php ENDPATH**/ ?>