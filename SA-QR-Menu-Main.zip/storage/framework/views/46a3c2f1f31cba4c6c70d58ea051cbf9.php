<aside class="admin-sidebar">
    <?php echo $__env->make('admin.restaurants.components.sidebar._user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.restaurants.components.sidebar._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</aside>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/sidebar/index.blade.php ENDPATH**/ ?>