<?php echo $__env->make('admin.restaurants.components.logo', ['restaurant' => $restaurant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.restaurants.components.menu-builder.index', [
  'restaurant' => $restaurant,
  'menuTree' => $menuTree,
  'locales' => $locales
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/edit/_menu.blade.php ENDPATH**/ ?>