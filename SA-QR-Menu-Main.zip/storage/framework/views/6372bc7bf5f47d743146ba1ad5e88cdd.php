<div style="margin-top:14px; display:flex; flex-direction:column; gap:10px;">
  <?php $__empty_1 = true; $__currentLoopData = $menuTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php ($catInactive = !$cat->is_active); ?>
    <div class="card <?php echo e($catInactive ? 'mb-inactive' : ''); ?>" style="padding:12px;">
      <div class="mb-row">
        <div class="mb-left">
          <form method="POST" action="<?php echo e(route('admin.restaurants.sections.toggle', [$restaurant, $cat])); ?>">
            <?php echo csrf_field(); ?>
            <label style="margin:0; display:flex; align-items:center; gap:8px;">
              <input type="checkbox" <?php if($cat->is_active): echo 'checked'; endif; ?> onchange="this.form.submit()">
              <span class="mb-item-title">
                <?php echo e($tTitle($cat, $defaultLocale) ?: ('Category #'.$cat->id)); ?>

              </span>
            </label>
          </form>

          <span class="mb-mini">ID: <?php echo e($cat->id); ?></span>
          <?php if($catInactive): ?>
            <span class="pill red"><?php echo e(__('admin.common.disabled') ?? 'disabled'); ?></span>
          <?php endif; ?>
        </div>

        <div class="mb-right mb-actions">
          <button class="btn small secondary" type="button"
                  data-mb-open="mbModalSubcategory"
                  data-parent-id="<?php echo e($cat->id); ?>">+ <?php echo e(__('admin.menu_builder.add_subcategory')); ?></button>

          <button class="btn small" type="button"
                  data-mb-open="mbModalItem"
                  data-section-id="<?php echo e($cat->id); ?>">+ <?php echo e(__('admin.menu_builder.add_item')); ?></button>

          <form method="POST" action="<?php echo e(route('admin.restaurants.sections.destroy', [$restaurant, $cat])); ?>"
                onsubmit="return confirm('Delete category and all nested data?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn small danger" type="submit"><?php echo e(__('admin.actions.delete') ?? 'Delete'); ?></button>
          </form>
        </div>
      </div>

      
      <?php echo $__env->make('admin.restaurants.components.menu-builder._items-list', [
        'restaurant' => $restaurant,
        'section' => $cat,
        'defaultLocale' => $defaultLocale
      ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      
      <div class="mb-sub" style="margin-top:12px;">
        <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php ($subInactive = !$sub->is_active); ?>
          <div class="card <?php echo e($subInactive ? 'mb-inactive' : ''); ?>" style="padding:12px; margin-top:10px;">
            <div class="mb-row">
              <div class="mb-left">
                <form method="POST" action="<?php echo e(route('admin.restaurants.sections.toggle', [$restaurant, $sub])); ?>">
                  <?php echo csrf_field(); ?>
                  <label style="margin:0; display:flex; align-items:center; gap:8px;">
                    <input type="checkbox" <?php if($sub->is_active): echo 'checked'; endif; ?> onchange="this.form.submit()">
                    <span class="mb-item-title">
                      <?php echo e($tTitle($sub, $defaultLocale) ?: ('Subcategory #'.$sub->id)); ?>

                    </span>
                  </label>
                </form>
                <span class="mb-mini">ID: <?php echo e($sub->id); ?></span>
                <?php if($subInactive): ?>
                  <span class="pill red"><?php echo e(__('admin.common.disabled') ?? 'disabled'); ?></span>
                <?php endif; ?>
              </div>

              <div class="mb-right mb-actions">
                <button class="btn small" type="button"
                        data-mb-open="mbModalItem"
                        data-section-id="<?php echo e($sub->id); ?>">+ <?php echo e(__('admin.menu_builder.add_item')); ?></button>

                <form method="POST" action="<?php echo e(route('admin.restaurants.sections.destroy', [$restaurant, $sub])); ?>"
                      onsubmit="return confirm('Delete subcategory and items?')">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn small danger" type="submit"><?php echo e(__('admin.actions.delete') ?? 'Delete'); ?></button>
                </form>
              </div>
            </div>

            <?php echo $__env->make('admin.restaurants.components.menu-builder._items-list', [
              'restaurant' => $restaurant,
              'section' => $sub,
              'defaultLocale' => $defaultLocale
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="mb-muted" style="margin-top:10px;">
      <?php echo e(__('admin.menu_builder.empty')); ?>

    </div>
  <?php endif; ?>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/menu-builder/_tree.blade.php ENDPATH**/ ?>