<div class="modal" id="mbModalItem" aria-hidden="true">
  <div class="modal__backdrop" data-mb-close></div>
  <div class="modal__panel">
    <div class="mb-row">
      <strong><?php echo e(__('admin.menu_builder.add_item')); ?></strong>
      <button class="btn small" type="button" data-mb-close>✕</button>
    </div>

    <form method="POST" enctype="multipart/form-data"
          action="<?php echo e(route('admin.restaurants.items.store', [$restaurant, 0, 0])); ?>"
          id="mbItemForm">
      <?php echo csrf_field(); ?>

      <input type="hidden" id="mbItemSectionId" name="_section_id" value="">

      <div class="grid" style="margin-top:10px;">
        <div class="col6">
          <label><?php echo e(__('admin.menu_builder.flags')); ?></label>
          <div style="display:flex; flex-direction:column; gap:8px;">
            <label class="perm-item"><input type="checkbox" name="is_active" value="1" checked> active</label>
            <label class="perm-item"><input type="checkbox" name="show_image" value="1" checked> show image + modal</label>
            <label class="perm-item"><input type="checkbox" name="is_new" value="1"> NEW</label>
            <label class="perm-item"><input type="checkbox" name="dish_of_day" value="1"> Dish of day</label>
          </div>
        </div>

        <div class="col6">
          <label><?php echo e(__('admin.menu_builder.spicy')); ?></label>
          <select name="spicy">
            <?php for($i=0;$i<=5;$i++): ?>
              <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>

          <label style="margin-top:10px;"><?php echo e(__('admin.menu_builder.image')); ?></label>
          <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
        </div>
      </div>

      <hr style="border:0;border-top:1px solid var(--line); margin:12px 0;">

      <div class="grid">
        <div class="col12">
          <div class="mb-muted"><?php echo e(__('admin.menu_builder.styles_hint')); ?></div>
        </div>

        <?php $__currentLoopData = ['title'=>'Title','desc'=>'Description','details'=>'Details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col4">
            <label><?php echo e($lbl); ?> font</label>
            <select name="style[<?php echo e($k); ?>][font]" data-style-font="<?php echo e($k); ?>">
              <option value="">—</option>
              <option value="inter">Inter</option>
              <option value="poppins">Poppins</option>
              <option value="roboto">Roboto</option>
              <option value="playfair">Playfair</option>
            </select>
          </div>
          <div class="col4">
            <label><?php echo e($lbl); ?> color</label>
            <input name="style[<?php echo e($k); ?>][color]" placeholder="#FFFFFF" data-style-color="<?php echo e($k); ?>">
          </div>
          <div class="col4">
            <label><?php echo e($lbl); ?> size</label>
            <input type="number" name="style[<?php echo e($k); ?>][size]" min="8" max="72" step="1" value="14" data-style-size="<?php echo e($k); ?>">
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="grid" style="margin-top:8px;">
        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col12">
            <label>Title (<?php echo e(strtoupper($loc)); ?>)</label>
            <input name="translations[<?php echo e($loc); ?>][title]" maxlength="50" required data-text-field="title">

            <label>Description (<?php echo e(strtoupper($loc)); ?>)</label>
            <input name="translations[<?php echo e($loc); ?>][description]" maxlength="250" data-text-field="desc">

            <label>Details (<?php echo e(strtoupper($loc)); ?>)</label>
            <textarea name="translations[<?php echo e($loc); ?>][details]" maxlength="500"
                      style="width:100%; min-height:90px; padding:10px 12px; border-radius:10px; border:1px solid var(--line); background:rgba(255,255,255,.03); color:var(--text);"
                      data-text-field="details"></textarea>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:10px;">
        <button class="btn ok" type="submit"><?php echo e(__('admin.actions.create') ?? 'Create'); ?></button>
      </div>
    </form>
  </div>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/menu-builder/_item-modal.blade.php ENDPATH**/ ?>