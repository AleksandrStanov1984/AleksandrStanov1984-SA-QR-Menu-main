<div id="passModal" class="modal" aria-hidden="true">
    <div class="modal__backdrop" onclick="closeModal('passModal')"></div>
    <div class="modal__panel">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
            <h2 style="margin:0;"><?php echo e(__('admin.profile.change_password.h2')); ?></h2>
            <button class="btn secondary small" type="button" onclick="closeModal('passModal')">X</button>
        </div>

        <form method="POST"
              action="<?php echo e(route('admin.profile.change_password')); ?>"
              style="margin-top:12px;"
              autocomplete="off">
            <?php echo csrf_field(); ?>

            <label><?php echo e(__('admin.profile.change_password.current_email')); ?></label>
            <input name="current_email" type="email" autocomplete="email" required>

            <label><?php echo e(__('admin.profile.change_password.current_password')); ?></label>
            <div class="pw-field">
                <input name="current_password" type="password" autocomplete="new-password" required>
                <button type="button" class="pw-toggle" aria-label="Show password">👁</button>
            </div>

            <label><?php echo e(__('admin.profile.change_password.new_password')); ?></label>
            <div class="pw-field">
                <input name="new_password" type="password" autocomplete="new-password" required>
                <button type="button" class="pw-toggle" aria-label="Show password">👁</button>
            </div>

            <label><?php echo e(__('admin.profile.change_password.confirm_new_password')); ?></label>
            <div class="pw-field">
                <input name="new_password_confirm" type="password" autocomplete="new-password" required>
                <button type="button" class="pw-toggle" aria-label="Show password">👁</button>
            </div>

            <div style="margin-top:14px; display:flex; gap:10px; justify-content:flex-end;">
                <button class="btn secondary" type="button" onclick="closeModal('passModal')">
                    <?php echo e(__('admin.common.cancel')); ?>

                </button>
                <button class="btn ok" type="submit">
                    <?php echo e(__('admin.common.change')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/profile/components/modals/change-password/index.blade.php ENDPATH**/ ?>