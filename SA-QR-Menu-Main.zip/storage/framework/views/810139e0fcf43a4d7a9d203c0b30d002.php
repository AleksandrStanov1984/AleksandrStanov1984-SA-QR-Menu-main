<?php
    $u = auth()->user();
    $canLanguages = $u?->is_super_admin || $u?->hasPerm('languages_manage') || $u?->hasPerm('import_manage');
?>

<?php if($canLanguages): ?>
<div class="card" style="margin-top:16px;">
    <h2><?php echo e(__('admin.languages.h2')); ?></h2>

    <div class="mut" style="font-size:12px; margin-bottom:10px;">
        <?php echo e(__('admin.languages.enabled')); ?>:
        <strong><?php echo e(implode(', ', $restaurant->enabled_locales ?: ['de'])); ?></strong>
        • <?php echo e(__('admin.languages.default')); ?>:
        <strong><?php echo e($restaurant->default_locale ?: 'de'); ?></strong>
    </div>

    <div class="grid">
        <div class="col6">
            <h3 class="mut" style="margin:0 0 8px 0;"><?php echo e(__('admin.languages.add_h3')); ?></h3>

            <form method="POST"
                  action="<?php echo e(route('admin.restaurants.languages.import', $restaurant)); ?>"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <label><?php echo e(__('admin.languages.locale_label')); ?></label>
                <input name="locale" value="<?php echo e(old('locale')); ?>" placeholder="en" required>

                <label><?php echo e(__('admin.languages.file_label')); ?></label>
                <input type="file" name="file" accept=".json,.txt" required>

                <label style="margin-top:10px;">
                    <input type="checkbox" name="is_default" value="1" <?php if(old('is_default')): echo 'checked'; endif; ?>>
                    <?php echo e(__('admin.languages.set_default_checkbox')); ?>

                </label>

                <div style="margin-top:12px;">
                    <button class="btn ok"><?php echo e(__('admin.languages.upload_import')); ?></button>
                </div>
            </form>
        </div>

        <div class="col6">
            <h3 class="mut" style="margin:0 0 8px 0;"><?php echo e(__('admin.languages.default_h3')); ?></h3>

            <form method="POST" action="<?php echo e(route('admin.restaurants.languages.default', $restaurant)); ?>">
                <?php echo csrf_field(); ?>

                <label><?php echo e(__('admin.languages.default_select_label')); ?></label>
                <select name="default_locale" required>
                    <?php ($enabled = $restaurant->enabled_locales ?: ['de']); ?>
                    <?php $__currentLoopData = $enabled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc); ?>" <?php if(($restaurant->default_locale ?: 'de') === $loc): echo 'selected'; endif; ?>>
                            <?php echo e(strtoupper($loc)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <div style="margin-top:12px;">
                    <button class="btn ok"><?php echo e(__('admin.languages.save_default')); ?></button>
                </div>
            </form>

            <div class="mut" style="font-size:12px; margin-top:10px;">
                <?php echo e(__('admin.languages.note_de_default')); ?>

            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card" style="margin-top:16px;">
    <h2><?php echo e(__('admin.languages.h2')); ?></h2>
    <div class="mut" style="font-size:12px;">
        <?php echo e(__('admin.languages.no_access')); ?>

    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/edit/_languages.blade.php ENDPATH**/ ?>