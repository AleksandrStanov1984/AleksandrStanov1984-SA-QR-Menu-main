<?php $__env->startSection('title', __('admin.profile.title')); ?>
<?php $__env->startSection('subtitle', __('admin.profile.subtitle')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('admin.breadcrumbs.dashboard')); ?></a>
    <span class="sep">/</span>

    <?php if(!empty($restaurant)): ?>
        <a href="<?php echo e(route('admin.restaurants.edit', ['restaurant' => $restaurant->id])); ?>"><?php echo e($restaurant->name); ?></a>
        <span class="sep">/</span>
    <?php endif; ?>

    <span><?php echo e(__('admin.profile.subtitle')); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.profile.components.restaurant-card.index', ['restaurant' => $restaurant ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('admin.profile.components.permissions-card.index', [
        'user' => $user,
        'permissions' => $permissions ?? []
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/profile.blade.php ENDPATH**/ ?>