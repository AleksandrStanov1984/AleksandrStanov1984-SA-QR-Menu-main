<!doctype html>
<html lang="<?php echo e(str_replace('_','-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('admin.layout.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

<?php echo $__env->make('admin.layout.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.layout.breadcrumbs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="wrap layout-with-sidebar">

    
    <?php if(auth()->guard()->check()): ?>
        <aside class="admin-sidebar">
            <?php echo $__env->make('admin.restaurants.components.sidebar.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>
    <?php endif; ?>

    
    <div class="main-content">
        <?php if(session('status')): ?>
            <div class="flash"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="errors">
                <strong><?php echo e(__('admin.common.fix_these')); ?></strong>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

</div>

<?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
window.openModal = function(id){
    const m = document.getElementById(id);
    if(!m) return;
    m.classList.add('is-open');
    m.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
}

window.closeModal = function(id){
    const m = document.getElementById(id);
    if(!m) return;
    m.classList.remove('is-open');
    m.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
}

// ESC закрывает открытую модалку
document.addEventListener('keydown', function(e){
    if(e.key !== 'Escape') return;
    const opened = document.querySelector('.modal.is-open');
    if(opened) {
        opened.classList.remove('is-open');
        opened.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }
});

window.openModal = function(id){
    const m = document.getElementById(id);
    if(!m) return;

    // ✅ жёстко чистим все input в модалке (и пароли, и email)
    m.querySelectorAll('input').forEach(inp => {
        inp.value = '';
        // сбросить также автозаполненные "ghost" значения
        inp.defaultValue = '';
    });

    m.classList.add('is-open');
    m.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
}

document.addEventListener('click', function(e){
  const btn = e.target.closest('.pw-toggle');
  if(!btn) return;
  const input = btn.closest('.pw-field')?.querySelector('input');
  if(!input) return;
  input.type = (input.type === 'password') ? 'text' : 'password';
});
</script>


</body>
</html>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/layout.blade.php ENDPATH**/ ?>