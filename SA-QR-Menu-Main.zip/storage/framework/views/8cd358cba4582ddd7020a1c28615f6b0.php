<div class="card">
    <h2><?php echo e(__('admin.restaurants.edit.h2')); ?></h2>

    <form method="POST" action="<?php echo e(route('admin.restaurants.update', $restaurant)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid">
            <div class="col6">
                <label><?php echo e(__('admin.fields.name')); ?></label>
                <input name="name"
                       value="<?php echo e(old('name', $restaurant->name)); ?>"
                       maxlength="20"
                       pattern="^[^\d<>]+$"
                       inputmode="text"
                       autocomplete="off"
                       required
                       data-capitalize="first"
                       data-no-digits="1">
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.template')); ?></label>
                <select name="template_key" required>
                    <?php $__currentLoopData = ['classic','fastfood','bar','services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tpl); ?>" <?php if($restaurant->template_key === $tpl): echo 'selected'; endif; ?>>
                            <?php echo e(__('admin.templates.'.$tpl)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.phone')); ?></label>
                <input name="phone"
                       value="<?php echo e(old('phone', $restaurant->phone)); ?>"
                       placeholder="+49123456789"
                       maxlength="16"
                       inputmode="tel"
                       autocomplete="off"
                       data-phone-e164="1">
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.city')); ?></label>
                <input name="city"
                       value="<?php echo e(old('city', $restaurant->city)); ?>"
                       maxlength="50"
                       pattern="^[^<>]*$"
                       autocomplete="off"
                       data-capitalize="first">
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.street')); ?></label>
                <input name="street"
                       value="<?php echo e(old('street', $restaurant->street)); ?>"
                       maxlength="50"
                       pattern="^[^<>]*$"
                       autocomplete="off"
                       data-capitalize="first">
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.house_number')); ?></label>
                <input name="house_number"
                       value="<?php echo e(old('house_number', $restaurant->house_number)); ?>"
                       maxlength="4"
                       pattern="^\d{1,3}[A-Za-z]?$"
                       placeholder="12A"
                       autocomplete="off">
            </div>

            <div class="col6">
                <label><?php echo e(__('admin.fields.postal_code')); ?></label>
                <input name="postal_code"
                       value="<?php echo e(old('postal_code', $restaurant->postal_code)); ?>"
                       maxlength="5"
                       pattern="^\d{5}$"
                       inputmode="numeric"
                       autocomplete="off">
            </div>
        </div>

        <div style="margin-top:16px">
            <button class="btn ok"><?php echo e(__('admin.actions.save')); ?></button>
        </div>
    </form>
</div>

<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/edit/_restaurant-form.blade.php ENDPATH**/ ?>