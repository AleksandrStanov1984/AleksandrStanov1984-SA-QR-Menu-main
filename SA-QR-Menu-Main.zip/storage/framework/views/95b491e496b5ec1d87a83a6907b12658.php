<?php if($errors->any()): ?>
<script>
    (function () {
        const errorFields = <?php echo json_encode(array_keys($errors->toArray()), 15, 512) ?>;
        const passwordFields = ['current_password', 'new_password', 'new_password_confirm'];

        if (errorFields.some(f => passwordFields.includes(f))) {
            openModal('passModal');
        }
    })();
</script>
<?php endif; ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/profile/components/errors-open-modal/index.blade.php ENDPATH**/ ?>