<?php if(auth()->user()->is_super_admin): ?>
<div class="card" style="margin-top:16px;">
    <h2><?php echo e(__('admin.permissions.h2')); ?></h2>

    <?php if(!$restaurantUser): ?>
        <div class="errors"><?php echo e(__('admin.permissions.no_user')); ?></div>
    <?php else: ?>
        <div class="perm-userline">
            <?php echo e(__('admin.permissions.user')); ?>:
            <strong><?php echo e($restaurantUser->name); ?></strong> (<?php echo e($restaurantUser->email); ?>)
        </div>

        <form method="POST" action="<?php echo e(route('admin.restaurants.user_permissions', $restaurant)); ?>">
            <?php echo csrf_field(); ?>

            <?php ($p = $restaurantUser->permissions ?? []); ?>

            <div class="perm-grid">
                <label class="perm-item">
                    <span>Языки</span>
                    <input type="checkbox" name="perm[languages_manage]" <?php if($p['languages_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Категории / Разделы</span>
                    <input type="checkbox" name="perm[sections_manage]" <?php if($p['sections_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Блюда / Позиции</span>
                    <input type="checkbox" name="perm[items_manage]" <?php if($p['items_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Баннеры</span>
                    <input type="checkbox" name="perm[banners_manage]" <?php if($p['banners_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Соцсети</span>
                    <input type="checkbox" name="perm[socials_manage]" <?php if($p['socials_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Тема</span>
                    <input type="checkbox" name="perm[theme_manage]" <?php if($p['theme_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Брендинг (фон, оформление)</span>
                    <input type="checkbox" name="perm[branding_manage]" <?php if($p['branding_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>

                <label class="perm-item">
                    <span>Импорт</span>
                    <input type="checkbox" name="perm[import_manage]" <?php if($p['import_manage'] ?? false): echo 'checked'; endif; ?>>
                </label>
            </div>



            <div style="margin-top:14px;">
                <button class="btn ok" type="submit"><?php echo e(__('admin.permissions.save')); ?></button>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/edit/_permissions.blade.php ENDPATH**/ ?>