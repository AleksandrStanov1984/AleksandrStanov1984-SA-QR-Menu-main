<?php
    $user = auth()->user();
?>

<div class="sb-user">
    
    <div class="sb-logo">
        <div class="sb-logo-circle"><?php echo e(__('admin.sidebar.logo')); ?></div>
    </div>

    <div class="sb-username">
        <?php echo e($user->name); ?>

    </div>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/sidebar/_user.blade.php ENDPATH**/ ?>