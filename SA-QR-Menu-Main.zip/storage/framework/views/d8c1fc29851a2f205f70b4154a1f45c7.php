<?php if (! empty(trim($__env->yieldContent('breadcrumbs')))): ?>
<div class="crumbs-wrap">
    <div class="crumbs">
        <?php echo $__env->yieldContent('breadcrumbs'); ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/layout/breadcrumbs.blade.php ENDPATH**/ ?>