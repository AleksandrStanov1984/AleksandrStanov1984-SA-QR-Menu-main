<footer style="border-top:1px solid var(--line);padding:12px 14px;font-size:12px;color:var(--mut);">
    © <?php echo e(date('Y')); ?> <?php echo e(__('admin.brand')); ?>

</footer>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>