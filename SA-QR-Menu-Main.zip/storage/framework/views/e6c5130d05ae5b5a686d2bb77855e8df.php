<?php $__env->startSection('title', __('admin.restaurants.index.title')); ?>
<?php $__env->startSection('subtitle', __('admin.restaurants.index.subtitle')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('admin.dashboard.home')); ?></a>
    <span class="sep">›</span>
    <span><?php echo e(__('admin.restaurants.index.h1')); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 12px;">
        <h1 style="margin:0; font-size:18px;">
            <?php echo e(__('admin.restaurants.index.h1')); ?>

        </h1>

        <a class="btn" href="<?php echo e(route('admin.restaurants.create')); ?>">
            <?php echo e(__('admin.restaurants.index.add')); ?>

        </a>
    </div>

    <div class="card">
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th><?php echo e(__('admin.fields.name')); ?></th>
                <th><?php echo e(__('admin.fields.slug')); ?></th>
                <th><?php echo e(__('admin.fields.template')); ?></th>
                <th><?php echo e(__('admin.fields.languages')); ?></th>
                <th><?php echo e(__('admin.fields.status')); ?></th>
                <th class="right"><?php echo e(__('admin.fields.actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r->id); ?></td>

                    <td><?php echo e($r->name); ?></td>

                    <td class="mut"><?php echo e($r->slug); ?></td>

                    <td class="mut">
                        <?php echo e(__('admin.templates.'.$r->template_key)); ?>

                    </td>

                    <td class="mut">
                        <?php echo e(implode(', ', $r->enabled_locales ?: ['de'])); ?>

                        <span class="pill" style="margin-left:6px;">
                            <?php echo e(__('admin.languages.default')); ?>:
                            <?php echo e($r->default_locale ?: 'de'); ?>

                        </span>
                    </td>

                    
                    <td>
                        <span class="status">
                            <span class="status-dot <?php echo e($r->is_active ? 'on' : 'off'); ?>"></span>
                            <?php echo e($r->is_active
                                ? __('admin.status.active')
                                : __('admin.status.inactive')); ?>

                        </span>
                    </td>

                    
                    <td class="right">
                        <div class="actions-inline">
                            <a class="btn small"
                               href="<?php echo e(route('admin.restaurants.edit', $r)); ?>">
                                <?php echo e(__('admin.actions.edit')); ?>

                            </a>

                            <form method="POST"
                                  action="<?php echo e(route('admin.restaurants.toggle', $r)); ?>">
                                <?php echo csrf_field(); ?>
                                <button
                                    class="btn small <?php echo e($r->is_active ? 'danger' : 'ok'); ?>"
                                    type="submit">
                                    <?php echo e($r->is_active
                                        ? __('admin.actions.deactivate')
                                        : __('admin.actions.activate')); ?>

                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 12px;">
            <?php echo e($restaurants->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/index.blade.php ENDPATH**/ ?>