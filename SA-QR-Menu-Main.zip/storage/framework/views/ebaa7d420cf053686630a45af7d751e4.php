<?php
    $u = auth()->user();

    if (!$u) {
        $brandUrl = route('admin.login');
    } elseif ($u->is_super_admin) {
        // super admin всегда может зайти на список ресторанов
        $brandUrl = route('admin.restaurants.index');
    } else {
        // обычный пользователь всегда заходит через "умный вход" в меню
        $brandUrl = route('admin.menu.profile');
    }
?>

<div class="topbar">
    <div class="topbar__left">
        <div class="brand"><a href="<?php echo e($brandUrl); ?>"><?php echo e(__('admin.brand')); ?></a></div>
        <div class="mut"><?php echo $__env->yieldContent('subtitle'); ?></div>
    </div>

    <div class="topbar__right">
        <form method="POST" action="<?php echo e(route('admin.locale.set')); ?>">
            <?php echo csrf_field(); ?>
            <select name="locale" onchange="this.form.submit()">
                <option value="de" <?php if(app()->getLocale()==='de'): echo 'selected'; endif; ?>>DE</option>
                <option value="en" <?php if(app()->getLocale()==='en'): echo 'selected'; endif; ?>>EN</option>
                <option value="ru" <?php if(app()->getLocale()==='ru'): echo 'selected'; endif; ?>>RU</option>
            </select>
        </form>

        <?php if(auth()->guard()->check()): ?>
            <a class="mut" href="<?php echo e(route('admin.profile')); ?>"><?php echo e($u->name); ?></a>

            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn secondary">
                    <?php echo e(__('admin.actions.logout')); ?>

                </button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/layout/topbar.blade.php ENDPATH**/ ?>