<div class="modal" id="mbModalCategory" aria-hidden="true">
  <div class="modal__backdrop" data-mb-close></div>
  <div class="modal__panel">
    <div class="mb-row">
      <strong><?php echo e(__('admin.menu_builder.add_category')); ?></strong>
      <button class="btn small" type="button" data-mb-close>✕</button>
    </div>

    <form method="POST" action="<?php echo e(route('admin.restaurants.categories.store', $restaurant)); ?>">
      <?php echo csrf_field(); ?>

      <div class="grid" style="margin-top:12px;">
        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col6">
            <label><?php echo e(__('admin.sections.categories.title')); ?> (<?php echo e(strtoupper($loc)); ?>)</label>
            <input name="title[<?php echo e($loc); ?>]" maxlength="50" required>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="grid" style="margin-top:12px;">
        <div class="col6">
          <label><?php echo e(__('admin.sections.categories.font')); ?></label>
          <select name="title_font">
            <option value="">—</option>
            <option value="inter">Inter</option>
            <option value="poppins">Poppins</option>
            <option value="roboto">Roboto</option>
            <option value="playfair">Playfair</option>
          </select>
        </div>
        <div class="col6">
          <label><?php echo e(__('admin.sections.categories.color')); ?></label>
          <input name="title_color" placeholder="#FFFFFF">
        </div>
      </div>

      <div style="margin-top:12px; display:flex; justify-content:flex-end; gap:10px;">
        <button class="btn ok" type="submit"><?php echo e(__('admin.sections.categories.create_btn')); ?></button>
      </div>
    </form>
  </div>
</div>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/menu-builder/_category-modal.blade.php ENDPATH**/ ?>