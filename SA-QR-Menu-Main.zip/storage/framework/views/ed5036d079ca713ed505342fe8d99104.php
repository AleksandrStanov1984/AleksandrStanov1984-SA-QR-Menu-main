<?php $__env->startSection('title', __('admin.auth.login.title')); ?>
<?php $__env->startSection('subtitle', __('admin.auth.login.subtitle')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" style="justify-content:center;">
        <div class="card" style="width: 420px; max-width: 100%;">
            <h2><?php echo e(__('admin.auth.login.h2')); ?></h2>

            <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                <?php echo csrf_field(); ?>

                <label><?php echo e(__('admin.fields.email')); ?></label>
                <input
                    type="email"
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    required
                    autofocus
                >

                <label><?php echo e(__('admin.fields.password')); ?></label>
                <input
                    type="password"
                    name="password"
                    required
                >

                <div style="margin-top: 14px; display:flex; justify-content:flex-end;">
                    <button class="btn" type="submit">
                        <?php echo e(__('admin.auth.login.submit')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>