<?php
  $locales = $locales ?? ($restaurant->enabled_locales ?: ['de']);

  $tTitle = fn($model, $loc) => optional($model->translations->firstWhere('locale', $loc))->title ?? '';
  $defaultLocale = $restaurant->default_locale ?: 'de';
?>

<?php echo $__env->make('admin.restaurants.components.menu-builder._styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card" style="margin-top:16px;">
  <div class="mb-row">
    <div>
      <h2 style="margin:0;"><?php echo e(__('admin.menu_builder.h2')); ?></h2>
      <div class="mb-muted"><?php echo e(__('admin.menu_builder.hint')); ?></div>
    </div>

    <button class="btn ok" type="button" data-mb-open="mbModalCategory">
      + <?php echo e(__('admin.menu_builder.add_category')); ?>

    </button>
  </div>

  
  <?php echo $__env->make('admin.restaurants.components.menu-builder._tree', [
    'restaurant' => $restaurant,
    'menuTree' => $menuTree,
    'locales' => $locales,
    'tTitle' => $tTitle,
    'defaultLocale' => $defaultLocale
  ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>


<?php echo $__env->make('admin.restaurants.components.menu-builder._category-modal', ['restaurant' => $restaurant, 'locales' => $locales], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.restaurants.components.menu-builder._subcategory-modal', ['restaurant' => $restaurant, 'locales' => $locales], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.restaurants.components.menu-builder._item-modal', ['restaurant' => $restaurant, 'locales' => $locales], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('admin.restaurants.components.menu-builder._scripts', ['restaurant' => $restaurant], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\aleks\DeuschProjects\SA-projekts\Projects\SA-QR-Menu-Main\resources\views/admin/restaurants/components/menu-builder/index.blade.php ENDPATH**/ ?>